# Operações aritmeticas no python

num1 = 8
num2 = 3

# Adicao
soma = num1 + num2
print(f"A soma dos numeros eh {soma}")


# Subtracao

subtracao = num1 - num2
print(f"A subtracao dos numeros eh {subtracao}")

# Multiplicacao
multiplicacao = num1 * num2

print(f"A multiplicacao dos numeros eh {multiplicacao}")

# Divisao
divisao = num1 / num2

print(f"A divisao dos numeros eh {divisao}")

# Limitar as casas decimais (exemplo: 2 casas decimais)
print(f"A divisão com duas casas decimais eh {divisao:.2f}")

# Exponenciacao
num1_cubo = num1 ** 3

print(f"{num1} elevado ao cubo eh {num1_cubo}")

# Resto da divisao
resto_divisao = num1 % 2

print(f"O resto da divisao de {num1} por 2 eh {resto_divisao}")

