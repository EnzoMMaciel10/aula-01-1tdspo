'''
Escreva um programa em python que solicite
tres notas de avaliacoes, calcule e mostre a media
aritmetica dessas avaliacoes
'''

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))
nota3 = float(input("Digite a terceira nota: "))

media = (nota1 + nota2 + nota3) / 3

print(f"A media das notas eh {media:.1f}")
