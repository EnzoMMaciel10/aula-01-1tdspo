'''
Escreva um programa em pyhton que solicite
dois numeros inteiros, calcule e mostre a soma desses numeros
'''

num1 = int(input("Digite o primeiro numero inteiro: "))
num2 = int(input("Digite o segundo numero inteiro: "))

soma = num1 + num2

print(f"A soma dos dois numeros eh {soma}")
