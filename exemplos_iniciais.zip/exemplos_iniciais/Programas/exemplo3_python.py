# Funcao para entrada de dadosno python (input)

# Entrada de uma variavel texto
nome_pessoa = input("Digite o nome da pessoa : ")

print(f"O nome da pessoa eh {nome_pessoa}")

# Entrada de uma variavel numerica inteira
idade_pessoa = int(input("Digite a idade da pessoa: "))

# print(type(idade_pessoa))

print(f"A idade da pessoa eh {idade_pessoa}")

# Entrada de uma variavel numerica real (float)
salario_funcionario = float(input("Digite o salario do funcionario"))

print(f"O salario do funcionario eh : {salario_funcionario:.2f}")
